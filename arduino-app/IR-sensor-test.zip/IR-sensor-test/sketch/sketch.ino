/*
 * sketch.ino — IR Tracker Sensor Test (Smartelex 5-Channel Tracker Sensor Module)
 * ==============================================================================
 *
 * This diagnostic sketch runs on the STM32U585 microcontroller of the Arduino Uno Q.
 * It interfaces with a Smartelex 5-Channel Tracker Sensor (TCRT5000-based reflection sensor),
 * reading the 5 analog sensor outputs (IR1-IR5) and printing their values to the App Lab console.
 *
 * Technical Specifications & Design Concepts:
 * -------------------------------------------
 * 1. Smartelex 5-Channel Tracker Sensor:
 *    - Operating Voltage: 3.3V – 5.0V DC. Connected to 5V.
 *    - Sensing element: TCRT5000 reflective optical sensor consisting of an infrared emitter
 *      (GaAs diode) and an infrared phototransistor (silicon NPN) side-by-side.
 *    - Output Type: 5 independent analog voltage outputs corresponding to the intensity of
 *      reflected IR light.
 *    - Reflection Mechanics:
 *      - Higher Reflection (light surface / nearby ball) -> NPN phototransistor conducts more ->
 *        collector voltage pulled lower -> analog voltage outputs a LOWER value (near 0V).
 *      - Lower Reflection (black line / empty space) -> NPN phototransistor is cut off ->
 *        collector voltage remains high -> analog voltage outputs a HIGHER value (near VCC).
 *
 * 2. Wiring Interface (7 Wires):
 *    - Pin 1 (VCC)  → Connected to Arduino 5V pin (provides power to the IR emitters and circuitry).
 *    - Pin 2 (GND)  → Connected to Arduino GND (common reference ground).
 *    - Pin 3 (IR1)  → Connected to analog pin A0 (Sensor channel 1 - leftmost).
 *    - Pin 4 (IR2)  → Connected to analog pin A1 (Sensor channel 2).
 *    - Pin 5 (IR3)  → Connected to analog pin A2 (Sensor channel 3 - center).
 *    - Pin 6 (IR4)  → Connected to analog pin A3 (Sensor channel 4).
 *    - Pin 7 (IR5)  → Connected to analog pin A4 (Sensor channel 5 - rightmost).
 *
 * 3. Modular Architecture:
 *    - Encapsulated in the `FiveChannelAnalogTracker` class to guarantee modularity and structure.
 */

// Include the Arduino Router Bridge library to enable serial output routing via MPU RPC.
#include <Arduino_RouterBridge.h>

/**
 * FiveChannelAnalogTracker Class
 * Encapsulates the operations of a 5-channel TCRT5000 infrared analog sensor array.
 * Provides modular methods to configure pins, read raw values, and calculate reflection percentages.
 */
class FiveChannelAnalogTracker {
  private:
    // Array of size 5 storing the MCU pin numbers mapped to each sensor output (IR1-IR5).
    int sensorPins[5];

    // The maximum possible reading from the Analog-to-Digital Converter.
    // By default, the UNO Q's ADC runs in 10-bit mode, giving a maximum value of 1023.
    int adcMaxVal;

  public:
    /**
     * Constructor - Initialises pin assignments.
     * @param p1 Analog pin for Sensor 1 (IR1)
     * @param p2 Analog pin for Sensor 2 (IR2)
     * @param p3 Analog pin for Sensor 3 (IR3)
     * @param p4 Analog pin for Sensor 4 (IR4)
     * @param p5 Analog pin for Sensor 5 (IR5)
     */
    FiveChannelAnalogTracker(int p1, int p2, int p3, int p4, int p5) {
        sensorPins[0] = p1; // Map Pin for Channel 1 to private storage array.
        sensorPins[1] = p2; // Map Pin for Channel 2 to private storage array.
        sensorPins[2] = p3; // Map Pin for Channel 3 to private storage array.
        sensorPins[3] = p4; // Map Pin for Channel 4 to private storage array.
        sensorPins[4] = p5; // Map Pin for Channel 5 to private storage array.
        adcMaxVal = 1023;   // Default maximum ADC reading for a 10-bit conversion.
    }

    /**
     * begin - Configures GPIO pins for analog reading.
     * Sets pins to input mode.
     */
    void begin() {
        // Loop through all five pins to configure their input mode.
        for (int i = 0; i < 5; i++) {
            // Set pin mode to INPUT to allow analogRead without pullups interfering with the analog voltage.
            pinMode(sensorPins[i], INPUT);
        }
    }

    /**
     * readRaw - Reads the raw analog state of a specific sensor channel.
     * @param index 0-based sensor channel index (0 = leftmost IR1, 4 = rightmost IR5).
     * @return int Raw ADC value (typically 0-1023).
     */
    int readRaw(int index) {
        // Bounds checking to avoid out-of-bounds memory reading of pin array.
        if (index < 0 || index >= 5) {
            // Return 0 if out of bounds to avoid memory fault.
            return 0;
        }
        // Query the MCU's ADC register for the corresponding pin.
        return analogRead(sensorPins[index]);
    }

    /**
     * getPercentage - Calculates reflection percentage for a channel.
     * 100% means highest reflection (sensor close to highly reflective surface).
     * 0% means lowest reflection (sensor over non-reflective surface or dark line).
     * Since lower analog values indicate higher reflection, we invert the percentage calculation.
     * @param index 0-based sensor channel index.
     * @return float The computed reflection percentage.
     */
    float getPercentage(int index) {
        // Bounds checking to avoid out-of-bounds memory reading.
        if (index < 0 || index >= 5) {
            // Return 0.0 if out of bounds.
            return 0.0;
        }
        // Read raw analog value from the specified channel pin.
        int rawVal = readRaw(index);
        // Map raw value to fraction of ADC max: 0.0 (maximum reflection) to 1.0 (minimum reflection).
        float fraction = (float)rawVal / adcMaxVal;
        // Invert fraction (so 0V/0 reading becomes 100% reflection, 1023 becomes 0% reflection).
        float percentage = (1.0 - fraction) * 100.0;
        // Return percentage.
        return percentage;
    }
};

// Global instance of FiveChannelAnalogTracker class initialized with pins:
// A0 (IR1), A1 (IR2), A2 (IR3), A3 (IR4), A4 (IR5) as specified in user manual.
FiveChannelAnalogTracker tracker(A0, A1, A2, A3, A4);

// Configures the loop execution interval in milliseconds.
// 200 ms (5 Hz) allows easy reading of console output without flooding the buffer.
const int SAMPLE_DELAY_MS = 200;

/**
 * setup() - Microcontroller initialisation routine.
 * Executed once when the board is booted or reset.
 */
void setup() {
    // Initialise hardware serial transceiver interface at 9600 baud rate.
    Serial.begin(9600);

    // Initialise the Router Bridge module to establish virtual serial interface to App Lab.
    Bridge.begin();

    // Call the begin method on our tracker object to configure analog pins.
    tracker.begin();

    // Print introductory diagnostic banner to App Lab console using print commands.
    Serial.println("=================================================");
    Serial.println("  5-CHANNEL ANALOG IR TRACKER SENSOR TEST");
    Serial.println("=================================================");
    Serial.println("Wiring Pinout (Sensor -> Arduino UNO Q):");
    Serial.println("  VCC (Power)  -> 5V Pin");
    Serial.println("  GND (Ground) -> GND Pin");
    Serial.println("  IR1 (Left)   -> Pin A0");
    Serial.println("  IR2 (Mid-L)  -> Pin A1");
    Serial.println("  IR3 (Center) -> Pin A2");
    Serial.println("  IR4 (Mid-R)  -> Pin A3");
    Serial.println("  IR5 (Right)  -> Pin A4");
    Serial.println("=================================================");
    Serial.println("Format: IR1[Raw|%Reflect] IR2[Raw|%Reflect] ... IR5");
    Serial.println("=================================================");
}

/**
 * loop() - Continuous application runtime routine.
 * Executed repeatedly after setup completes.
 */
void loop() {
    // Print a leading tag for the status line.
    Serial.print("Sensors: ");

    // Loop through all 5 channels to format and output their status.
    for (int i = 0; i < 5; i++) {
        // Read raw analog value of current channel.
        int raw = tracker.readRaw(i);
        
        // Calculate the reflection percentage.
        float percent = tracker.getPercentage(i);

        // Print header for individual sensor.
        Serial.print("IR");
        // Print channel index (1-based for human display).
        Serial.print(i + 1);
        Serial.print(":[");
        // Print the raw ADC value.
        Serial.print(raw);
        // Print delimiter.
        Serial.print("|");
        // Print the reflection percentage.
        Serial.print(percent, 1);
        Serial.print("%] ");
    }

    // Print new line feed to terminate the status output line.
    Serial.println();

    // Pause execution to throttle output rate to 5 Hz.
    delay(SAMPLE_DELAY_MS);
}
